(function() {
  fetch(
    "https://raw.githubusercontent.com/ShootProof/recruiting-front-end/master/testdata.json"
  )
    .then(response => response.json())
    .then(data => assembleHTML(data));

  function transformObj(obj, parentNode, tree) {
    tree = typeof tree !== "undefined" ? tree : [];
    parentNode = typeof parentNode !== "undefined" ? parentNode : { id: null };

    var children = _.filter(obj, function(child) {
      return child.parent == parentNode.id;
    });

    if (!_.isEmpty(children)) {
      if (parentNode.id == null) {
        tree = children;
      } else {
        parentNode["children"] = children;
      }
      _.each(children, function(child) {
        transformObj(obj, child);
      });
    }

    return tree;
  }

  function assembleHTML(data) {
    const unflattenData = transformObj(data);

    function mutateDom(container, jsonData) {
      for (let i = 0; i < jsonData.length; i++) {
        const $divParent = $("<div></div>");
        $divParent.attr("id", jsonData[i].id);
        $divParent.append("<div class='container'></div>");
        $divParent
          .find(".container")
          .append(
            `<img src="${jsonData[i].thumbnail.href}" title="${jsonData[i].thumbnail.description}">`
          );
        $divParent
          .find(".container")
          .append(`<span>${jsonData[i].name}</span>`);

        if (jsonData[i].children) {
          $divParent.find(".container").addClass("caret");
          $divParent.append("<div class='nested'></div>");
          mutateDom($divParent.find(".nested"), jsonData[i].children);
        }
        container.append($divParent);
      }
    }

    function attachEventListeners() {
      const parentElements = document.getElementsByClassName("container");

      for (let i = 0; i < parentElements.length; i++) {
        parentElements[i].addEventListener("click", function() {
          this.parentElement
            .querySelector(".nested")
            .classList.toggle("active");
          this.classList.toggle("caret-down");
        });
      }
    }

    mutateDom($("body"), unflattenData);
    attachEventListeners();
  }
})();
